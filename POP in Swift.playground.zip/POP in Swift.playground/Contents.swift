//: # Protocols Playground

/*: 
## Define a *public* protocol with name `SingleValued` 
*Optional*: make the protocol aggregate `CustomStringConvertible`.
*/
public protocol SingleValued: CustomStringConvertible {
/*: 
Conforming objects must define:
- an associated `Magnitude` for said protocol;
*/
	associatedtype Magnitude
/*:
- a `magnitude` stored property of type `Magnitude`;
*/
	var magnitude: Magnitude { get }
/*:
- an initializer, taking an anonymous `Magnitude` value.
*/
	init(_ magnitude: Magnitude)
}

/*: 
## Extend `SingleValued`
*/
extension SingleValued {
/*: 
Define a *public* function returning the name of the actual type of `self.magnitude` as a String.
*/
	public var typeName: String { return String(describing: type(of: self.magnitude)) }
/*:
*Optional:* Provide a default value, for the `description` computed property required by `CustomStringConvertible`,
yielding a `String` describing `self.magnitude`.
*/
	public var description: String { return String(describing: self.magnitude) }
}

/*: 
## Extend `SingleValued` only if `Magnitude` is `Int`
*/
extension SingleValued where Self.Magnitude == Int {
/*: 
Define *public* `min` and `max` computed properties returning an instance of the same type storing
the minimum and maximum Int values, respectively.
*/
	public var min: Self { return Self(Int.min) }
	public var max: Self { return Self(Int.max) }
}


/*: 
##
Define a *public* `NumericValue` struct.
This is a struct with one generic parameter (let's name it `T`) conforming to the `SingleValued` protocol.
*/
public struct NumericValue<T>: SingleValued {//, CustomStringConvertible {
/*:
Define a *public* type `Magnitude` aliasing `T`
*/
	public typealias Magnitude = T
/*:
Define a *public* stored
*/
	public var magnitude: T
/*: 
Define a *public* initializer taking one anonymous argument of type T.
*/
	public init(_ magnitude: T) {
		self.magnitude = magnitude
	}

//	public var description: String { return String(describing: self.magnitude) }
}

/*: 
## Let's instantiate two `NumericValues`
- an instance `x` with initial value `1`;
- an instance `y` with initial value `1.0`;
*/
var x = NumericValue(1)
var y = NumericValue(1.0)

/*:
Let's see the type of `x.magnitude`...
*/
x.typeName
/*:
and the type of `y.magnitude`.
*/
y.typeName

/*:
Let's see the `max` anc `min` values of `x`...
*/
x.min
x.max
/*:
and those of `y`.
*/
// y.min
// y.max

/*:
*ERROR:* y.magnitude is not an `Int` value!
*/

/*:
## Let's extend our `NumericValue` when `Magnitude` conforms to the `Integer` protocol.
*/
extension NumericValue where T: Integer {
/*:
Define a *public* computed property `next` returning a `NumericValue` of the same kind representing the next integer value.
*/
	public var next: NumericValue { return NumericValue(self.magnitude.advanced(by: 1)) }
}

/*:
Let's see what comes after `1`...
*/
x.next
/*:
Let's see what comes after `1.0`...
*/
//y.next
/*:
*ERROR:* y.magnitude does not conform to `Integer`!
*/

extension SingleValued where Self: FloatingPoint {

}


/*:
## Nicely done! Have a good week!
Gianluca Salvato
*/

